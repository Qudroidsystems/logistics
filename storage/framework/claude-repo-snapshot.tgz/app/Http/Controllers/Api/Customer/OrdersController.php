<?php

namespace App\Http\Controllers\Api\Customer;

use App\Http\Controllers\Controller;
use App\Modules\Marketplace\CancellationService;
use App\Modules\Marketplace\FailedDeliveryPolicy;
use App\Modules\Returns\PickupPointService;
use App\Modules\Verification\VerificationPolicy;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use RuntimeException;

/** The customer's own orders: a list for the app's home screen and one detail call with everything the order screen needs. */
class OrdersController extends Controller
{
    private const FINISHED = ['delivered', 'completed', 'cancelled', 'confirmed'];

    public function index(Request $request)
    {
        $q = DB::table('orders as o')->join('shipments as s', 's.order_id', '=', 'o.id')->join('operators as p', 'p.id', '=', 's.operator_id')
            ->where('o.customer_id', $request->user()->id)->orderByDesc('o.id')->limit(100)
            ->select('s.public_id as shipment', 's.status', 's.tracking_code', 'o.order_number', 'o.total', 'o.created_at', 'p.display_name as provider');

        $filter = $request->query('status', 'all');
        if ($filter === 'active') {
            $q->whereNotIn('s.status', self::FINISHED);
        } elseif ($filter === 'done') {
            $q->whereIn('s.status', self::FINISHED);
        }

        return response()->json($q->get()->map(fn ($r) => (array) $r + ['active' => ! in_array($r->status, self::FINISHED, true)])->all());
    }

    public function show(Request $request, string $shipment, CancellationService $cancel)
    {
        $s = DB::table('shipments as s')->join('orders as o', 'o.id', '=', 's.order_id')->join('operators as p', 'p.id', '=', 's.operator_id')
            ->where('s.public_id', $shipment)->where('o.customer_id', $request->user()->id)
            ->first(['s.id', 's.public_id', 's.status', 's.tracking_code', 's.delivered_at', 's.pickup_window_start', 'o.order_number', 'o.total', 'o.discount', 'o.payment_status', 'o.agreement_id', 'p.display_name as provider', 's.created_at']);
        abort_unless($s, 404);

        $stops = DB::select('SELECT seq, type, line1, landmark, status, ST_Y(point::geometry) AS lat, ST_X(point::geometry) AS lng FROM shipment_stops WHERE shipment_id = ? ORDER BY seq', [$s->id]);
        $rated = DB::table('ratings')->where(['shipment_id' => $s->id, 'rater_type' => 'customer'])->exists();
        $token = DB::table('tracking_links')->where('shipment_id', $s->id)->where('audience', 'customer')->whereNull('revoked_at')
            ->where(fn ($q) => $q->whereNull('expires_at')->orWhere('expires_at', '>', now()))->value('token');

        $agreement = DB::table('agreements')->where('id', $s->agreement_id ?? 0)->first();
        $isShopping = $agreement && DB::table('shopping_requests')->where('agreement_id', $agreement->id)->exists();
        $stage = $cancel->stage($s->status);
        $policy = $agreement && $agreement->failed_delivery_policy ? json_decode($agreement->failed_delivery_policy, true) : null;
        $point = app(PickupPointService::class)->forCustomer((int) $s->id);

        return response()->json([
            'shipment' => $s->public_id, 'status' => $s->status, 'tracking_code' => $s->tracking_code, 'tracking_token' => $token,
            'order_number' => $s->order_number, 'total' => (int) $s->total, 'provider' => $s->provider, 'created_at' => $s->created_at, 'delivered_at' => $s->delivered_at,
            'stops' => array_map(fn ($x) => ['seq' => $x->seq, 'type' => $x->type, 'address' => $x->line1, 'landmark' => $x->landmark, 'status' => $x->status, 'lat' => (float) $x->lat, 'lng' => (float) $x->lng], $stops),
            'timeline' => DB::table('shipment_events')->where('shipment_id', $s->id)->orderBy('seq')->get(['type', 'created_at']),
            'packages' => app(\App\Modules\Tracking\ParcelCodes::class)->forShipment((int) $s->id),
            'can_cancel' => $stage !== 'not_cancellable', 'can_confirm' => $s->status === 'delivered',
            'can_rate' => in_array($s->status, ['confirmed', 'completed'], true) && ! $rated,
            'shows_code' => ! in_array($s->status, [...self::FINISHED, 'created', 'awaiting_dispatch'], true),
            'agreement' => $agreement->public_id ?? null, 'is_shopping' => $isShopping,
            'terms' => $this->terms($policy),
            // Proof of delivery both sides agreed; the driver cannot finish the drop-off without them.
            'verification' => $this->proofs((int) $s->id, $point),
            // Set when the drop-off is one of the provider's pickup points: where to collect, and until when.
            'pickup_point' => $point,
            // Chat and calls with the rider while one is on the job.
            'chat' => app(\App\Modules\Messaging\ChatService::class)->summary((int) $s->id, $request->user()->id),
            // Goods money the rider collects from the receiver, and whether the provider has paid it to you yet.
            'cod' => app(\App\Modules\Cod\CodService::class)->forShipment((int) $s->id),
            // Booking extras: when it should be collected, any discount, the request's photos/documents and whether a receipt can be downloaded.
            'pickup_at' => \App\Modules\Booking\LocalTime::iso($s->pickup_window_start), 'rush' => (bool) ($agreement && $agreement->request_id
                ? DB::table('service_requests')->where('id', $agreement->request_id)->value('rush') : false),
            'discount' => (int) $s->discount, 'receipt_available' => $s->payment_status === 'paid',
            'files' => app(\App\Modules\Booking\RequestAttachments::class)->forShipment((int) $s->id),
        ]);
    }

    /** At a pickup point the receiver collects with a code once the parcel is there, whatever was agreed for a door. */
    private function proofs(int $shipmentId, ?array $point): array
    {
        $p = app(VerificationPolicy::class)->forShipment($shipmentId);

        return ['pickup' => VerificationPolicy::describe($p['pickup']), 'dropoff' => VerificationPolicy::describe($p['dropoff']),
            'uses_code' => $point ? $point['waiting'] : in_array('code', $p['dropoff'], true), 'authorised_receivers' => $p['authorised_receivers']];
    }

    private function terms(?array $policy): mixed
    {
        try {
            return FailedDeliveryPolicy::describe($policy);
        } catch (RuntimeException) {
            return null;
        }
    }
}
